# BDSM

Of course it stands for: **_Browser DSA Stat Manager_** and nothing else you horny guys.  
The goal is to create a cross-platform application for keeping track of your hero stats in the german pen & paper game [Das schwarze Auge](https://ulisses-spiele.de/game-system/das-schwarze-auge/) from [Ulisses Spiele](https://ulisses-spiele.de/).

## Improvement

Feedback or suggestions are highly appreciated, either for missing/wrong background stuff or to compensate my lack of front-end development skills.

## Note

I have never worked with databases before so don't be too mad if I screwed up something badly but instead leave an issue or a even a Pull Request, thank you.

# Credits

The initial idea comes from the C# Application [DELM](https://github.com/Ducttapemummy/DELM).  
And of course the project would not be possible without:

-   The contributors to the [Optolith Project](https://github.com/elyukai/optolith-client).
-   The playmaker [Ulisses Spiele](https://ulisses-spiele.de/).
